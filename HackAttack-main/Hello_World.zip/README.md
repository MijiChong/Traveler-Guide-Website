Project description

This web acts as an intermediate between tourists and tour guides. This project aims to offer insights from locals or experienced travelers, giving users tips on the best places in Malaysia to eat and visit. This website also resolves language barrier which can limit tourists' cultural immersion and their capacity to get assistance when necessary.